/* mpt5a.c 
 * C/ASM Mix test for TI Stellaris LM3S6965 (ARM Cortex-M3) 
 * Using startup.c 
 * LV  2522 Mikroprozessortechnik SS20
 * Marcus Thoss 
 */

#include <stdio.h>
#include <stdlib.h>
#include "addfunc.h"
#include "stellaris_uart.h"


/* void uartPrintFlags(unsigned long flags) */
  /* TODO: insert the missing implementation here */


int main() {

  /* TODO: main implementation goes here */
  return 0;
}
