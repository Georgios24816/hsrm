class CookingTimer
{
public:
	CookingTimer(int seconds) : m_seconds(seconds), m_secondsRemaining(seconds) {}

	int getSeconds() const { return m_seconds; }
	void setSeconds(int seconds) 
	{ 
		m_seconds = seconds; 
		m_secondsRemaining = seconds;
	}

	int getSecondsRemaining() const { return m_secondsRemaining; }
	void setSecondsRemaining(int seconds)
	{
		if (seconds <= m_seconds)
			m_secondsRemaining = seconds;
	}


	void startCountdown() {} //Implementierung nicht verlangt	
	void stopCountdown() {}	//Implementierung nicht verlangt	
	void printCountdown() {} //Implementierung nicht verlangt, deshalb fehlt <iostream>
	void reset() { m_secondsRemaining = m_seconds; }

private:
	int m_seconds = 10; //Defaultwerte, falls Default-Konstruktor aufgerufen wird, weil
	int m_secondsRemaining = 10; //CookingTimer() = delete wird von älteren Compilern nicht unterstützt
};

int main()
{

	return 0;
}
