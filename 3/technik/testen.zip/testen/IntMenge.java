package de.duddaweb.misc.testen;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public class IntMenge {
    private Set<Integer> menge = new HashSet<Integer>();

    public IntMenge(int i) {
        menge.add(i);
    }

    public IntMenge() {

    }

    public IntMenge(int i, int i1) {
        menge.add(i);
        menge.add(i1);
    }

    public void einfuegen(int el) {
        menge.add(el);
    }

    public void entfernen(int el) {
        menge.remove(el);
    }

    public int getIrgendeinElement() throws LeereMengeException {
        if (groesse() <= 0) { // leer
            throw new LeereMengeException();
        }
        int randomNum = ThreadLocalRandom.current().nextInt(0, menge.size());
        return (Integer) menge.toArray()[randomNum];
    }

    public int[] getInhalt() {
        return menge.stream().mapToInt(i -> i).toArray();
    }

    public int groesse() {
        return menge.size();
    }

    public boolean istEnthalten(int el) {
        return menge.contains(el);
    }

    public class LeereMengeException extends Exception {
    }
}
