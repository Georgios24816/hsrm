package de.duddaweb.misc.testen;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class IntMengeTest {
    private IntMenge intMenge;

    // Ansatz 1 = Antipattern
    @Test
    public void einfuegen() {
        intMenge = new IntMenge();
        assertEquals(0, intMenge.groesse());
        intMenge.einfuegen(1);
        assertEquals(1, intMenge.groesse());
        assertArrayEquals(new int[]{1}, intMenge.getInhalt()); // [1], [1]
    }

    @Test
    public void einfuegen2() {
        einfuegen();
        intMenge.einfuegen(2);
        assertArrayEquals(new int[]{1, 2}, intMenge.getInhalt()); // [1,2], [1,2]
    }


    // zustandsbasierter Test: 2 Zustände: „leer“ und „nicht leer“
    // Kombination jeder Zustand mit jedem möglichen Ereignis
    // Ereignisse = einfuegen, entfernen, getIrgendeinElement

    // leer
    @Test
    public void leerEinfuegen() { // 1
        intMenge = new IntMenge();
        assertEquals(0, intMenge.groesse());
        intMenge.einfuegen(1);
        assertNotEquals(0, intMenge.groesse()); // nicht leer
    }

    @Test
    public void leerEntfernen() { // 2
        intMenge = new IntMenge();
        assertEquals(0, intMenge.groesse());
        intMenge.entfernen(1);
        assertEquals(0, intMenge.groesse());
    }

    @Test
    public void leerGetIrgendeinElement() { // 3
        intMenge = new IntMenge();
        assertEquals(0, intMenge.groesse());
        assertThrows(IntMenge.LeereMengeException.class, () -> intMenge.getIrgendeinElement());
    }

    // nicht leer
    @Test
    public void nleerEinfuegenContainsNot() { // 4
        intMenge = new IntMenge(1);
        assertNotEquals(0, intMenge.groesse()); // nicht leer
        int tmpGroesse = intMenge.groesse(); // = 1
        intMenge.einfuegen(2); // x not in intMenge
        assertEquals(tmpGroesse + 1, intMenge.groesse()); // groesse++
    }

    @Test
    public void nleerEinfuegenContains() { // 5
        intMenge = new IntMenge(1);
        assertNotEquals(0, intMenge.groesse()); // nicht leer
        int tmpGroesse = intMenge.groesse(); // = 1
        intMenge.einfuegen(1); // x in intMenge
        assertEquals(tmpGroesse, intMenge.groesse()); // groesse == tmpGroesse
    }

    @Test
    public void nleerEntfernenContainsNot() { // 6
        intMenge = new IntMenge(1);
        assertNotEquals(0, intMenge.groesse()); // nicht leer
        int tmpGroesse = intMenge.groesse(); // = 1
        intMenge.entfernen(3); // x not in intMenge
        assertEquals(tmpGroesse, intMenge.groesse());
    }

    @Test
    public void nleerEntfernenContainsGT1() { // 7
        intMenge = new IntMenge(1, 2);
        assertNotEquals(0, intMenge.groesse()); // nicht leer
        assertTrue(intMenge.groesse() > 1);
        int tmpGroesse = intMenge.groesse(); // > 1
        intMenge.entfernen(1); // x not in intMenge
        assertEquals(tmpGroesse - 1, intMenge.groesse());
        assertNotEquals(0, intMenge.groesse()); // nicht leer, Zustand bleibt
    }

    @Test
    public void nleerEntfernenContainsEQ1() { // 8
        intMenge = new IntMenge(1);
        assertNotEquals(0, intMenge.groesse()); // nicht leer
        assertTrue(intMenge.groesse() == 1);
        int tmpGroesse = intMenge.groesse(); // = 1
        intMenge.entfernen(1); // x not in intMenge
        assertEquals(tmpGroesse - 1, intMenge.groesse());
        assertEquals(0, intMenge.groesse()); // nicht leer => leer, Zustandswechsel
    }
    @Test
    public void nleerGetIrgendeinElement() throws IntMenge.LeereMengeException { // 9
        intMenge = new IntMenge(1,4);
        assertEquals(2, intMenge.groesse());
        assertEquals(1, intMenge.getIrgendeinElement());
    }

    // 10 => Konstruktor
}
