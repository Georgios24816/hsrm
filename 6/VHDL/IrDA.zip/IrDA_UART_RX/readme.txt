
Subfolder content:
1. source contains the demo source files 
2. impl contains the iCEcube project
3. constraint contains constraint file

How to regenerate bit file:
1. lauch iCEcube
2. open project impl_sbt.project under \impl
3. run through the flow to generate bit file
4. the generated bit files are under \impl\impl_Implmnt\sbt\outputs\bitmap