#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void killMe() {
    char command[20];
    int pid = getpid();
    sprintf(command, "kill %d", pid);
    system(command);
}

int main(int argc, char *argv[]){
    printf("I don't want to live anymore...\n");
    killMe();
}


