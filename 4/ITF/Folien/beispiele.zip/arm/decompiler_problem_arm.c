#include <stdlib.h>
#include <stdio.h>

long c;
register long *b asm("r12");

void setupRegisterPointer() {
    b = &c;
}

void setValue(long x) {
    *b = x;
}

long getValue() {
    return *b;
}

int main(int argc, char* argv[]) {
    setupRegisterPointer();
    setValue(5);
    long value = getValue();

    printf("Register Value: %lu\n", value);
    return 0;
}

