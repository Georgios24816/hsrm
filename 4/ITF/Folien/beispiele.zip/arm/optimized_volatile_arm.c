#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    int limit = 1000;
    volatile long counter = 0;

    for(int i = 0; i < limit; i++) {
        for(int j = 0; j < limit; j++) {
            counter += 1;
        }
    }
    printf("Counter value: %d\n", counter);
    if(counter == limit * limit) {
        printf("Unchanged Program Flow");
    }
    else {
        printf("Changed Program Flow");
    }
    return 0;
}


