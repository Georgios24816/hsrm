#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

struct Person
{
    int citNo;
    char name[50];
    float salary;
} typedef _Person_t;

void print_person(_Person_t *p) {
    printf("name: %s\n", p->name);
    printf("cityNo: %d\n", p->citNo);
    printf("salary: %g\n", p->salary);
}

int main(int argc, char *argv[]){

    _Person_t *p1 = malloc(sizeof(_Person_t));
    char *name = "Jhon Doe";
    strcpy(p1->name, name);
    p1->citNo = 5;
    p1->salary = 12345.50;
    print_person(p1);
    return 0;
}


