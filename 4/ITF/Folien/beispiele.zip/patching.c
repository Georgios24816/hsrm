#include <stdio.h>
#include <string.h>

void main(int argc, char *argv[]) {
    char pass[20] = "password";
    char pass_buf[20];

    gets(pass_buf);                             
    printf("Entered Password: %s\n", pass_buf);

    if(strcmp(pass_buf, pass) != 0){
        printf("Wrong Password! Try Again.\n");
        return;
    }

    printf("Unlocked!\n");
}

